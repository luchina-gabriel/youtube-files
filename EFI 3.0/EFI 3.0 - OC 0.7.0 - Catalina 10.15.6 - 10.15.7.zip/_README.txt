PLEASE UPDATE 'PlatformInfo' with YOUR infos 'config.plist'

	MLB 					- Board Serial
	ROM 					- Mac Address (characteres and numbers only)
	SystemSerialNumber 		- Serial
	SystemUUID 				- SmUUID

* I recommend you use ProperTree for updates in config.plist
