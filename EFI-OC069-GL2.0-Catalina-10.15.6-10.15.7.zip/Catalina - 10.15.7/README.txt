EFI para macOS Catalina - versão 10.15.6 e 10.15.7

	OpenCore 0.6.9
	Correção de discos NVME que eram reconhecidos como externos
	Correção de gerenciamento de energia do processador e portas USB
	Patch para uso máximo do Xeon com undervolt e unlock do turbo boost
	Limpeza do arquivo de configuraçã
	Rename de portas USB para o mesmo padrão da Apple
	Habilitado modo gráfico do OpenCore - Opencanopy
	Compilação de tabelas ACPI baseadas na Huananzhi F8
	
Versão da EFI: 2.0 - 04/06/2021

!!! NÃO ESQUECER DE TROCAR OS VALORES DE MLB, SystemSerialNumber, SystemUUID E ROM no config.plist !!!
